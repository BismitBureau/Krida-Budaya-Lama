<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cover extends Model
{
    //
}
