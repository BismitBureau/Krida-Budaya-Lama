<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class people extends Model
{
    //
}
