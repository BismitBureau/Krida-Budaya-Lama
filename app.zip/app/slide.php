<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class slide extends Model
{
    //
}

class news_slide extends Model
{
    //
}