<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title> Admin Kridabudaya </title>
    <title> admin </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="row">
      <div class="col-sm-4"> </div>
      <div class="col-sm-4" style="margin-top: 100px">
        <div class="panel panel-default">
          <div class="panel-heading">Login</div>
          <div class="panel-body">
            <form method="post" role="form">
             <div class="form-group">
               <label for="username">Username:</label>
               <input type="username" class="form-control" name="name">
             </div>
             <div class="form-group">
               <label for="pwd">Password:</label>
               <input type="password" class="form-control" name="password">
             </div>
             <div class="checkbox">
               <label><input type="checkbox"> Remember me</label>
             </div>
             <button type="submit" class="btn btn-default">Submit</button>
           </form>
          </div>
        </div>
      </div>
      <div class="col-sm-4"> </div>
    </div>
  </body>
</html>
