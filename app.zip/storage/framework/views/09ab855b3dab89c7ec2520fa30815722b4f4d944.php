<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Achievement
        <small>Edit</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/')); ?>"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li><a href="<?php echo e(url('admin/achievements')); ?>"> Achievements</a></li>
        <li class="active"><a href="#">Edit</a></li>
    </ol>
</section>
<section class="content">
	<div class="box box-warning">
		<form role="form" method="post" action="<?php echo e(url('admin/update_achievement/'.$achievement['id'])); ?>">
        <div class="box-body">
                <div class="form-group">
                    <label>Year</label>
                    <input type="text" name="year" class="form-control" placeholder="Enter ..." value="<?php echo e($achievement['year']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Content English</label>
                    <input type="text" name="stringen" class="form-control" placeholder="Enter ..." value="<?php echo e($achievement['stringen']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Content Indonesia</label>
                    <input type="text" name="stringid" class="form-control" placeholder="Enter ..." value="<?php echo e($achievement['stringid']); ?>" required>
                </div>
        </div>
        <div class="box-footer">
        	<button type="submit" class="btn btn-primary">Save</button>
        </div>
        </form>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>