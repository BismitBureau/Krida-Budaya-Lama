<!DOCTYPE html>
<html>
  <head>
    <title> Krida Budaya | Liga Tari Mahasiswa Universitas Indonesia </title>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <!--<link rel="stylesheet" href="<?php echo e(url('style/master.css')); ?>"> --> <?php echo $__env->yieldContent('styling'); ?>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="<?php echo e(url('javascript/myScript.js')); ?>"></script>
  </head>
  
  <?php if(!isset($mobilemode)): ?>
	  <script>
		$(document).ready(function() {
		  var temp = "<?php echo url('m/'.$lang.'/'.$curpage); ?>";
		  if(window.devicePixelRatio > 1) {
			$(location).attr('href',temp);
		  }
		});
	  </script>
  <?php endif; ?>
  <body>
    <div id="top"> </div>
  	<button class="upBtn btn btn-default"> <img src="<?php echo e(url('images/arrow.png')); ?>"> </button>
  	<header>
  		<div class="row">
  			<div class="col-sm-4 navcol-1">
  				<img src="<?php echo e(url('images/logo.png')); ?>" class="img-responsive" style="margin: 0 auto" width="auto">
  			</div>
  			<div class="col-sm-8 navcol-2" style="padding:0px">
  				<table class="headerMenus">
  					<tr>
  						<td>
  							<div class="btn-group">
								<button type="button " class="btn btn-default topBtn collapseBtn" onclick="collapseToggle()"><span class="glyphicon glyphicon-align-justify"></span></button>
								<button type="button " class="btn btn-default topBtn topSpecial"><span class="glyphicon glyphicon-search"></span></button>
								<div class="btn-group">
									<button type="button" class="btn btn-default dropdown-toggle topBtn" data-toggle="dropdown"> 
										<?php if(strcmp($lang,'en')==0): ?> 
											EN 
										<?php else: ?> 
											ID 
										<?php endif; ?> 
										<span class="caret"></span> 
									</button>
									<ul class="dropdown-menu dropdown-menu-right" role="menu">
										<li class="navbar-dropdown">
											<a href="<?php echo e(url('/')); ?>/id/<?php echo e($curpage); ?>">BAHASA INDONESIA</a>
										</li>
										<li class="navbar-dropdown">
											<a href="<?php echo e(url('/')); ?>/en/<?php echo e($curpage); ?>">TES</a>
										</li>
									</ul>
  							  </div>
  							</div>
  						</td>
  					</tr>
  					<tr>
  						<td>
							<div class="btn-group" id="navbar">
								<a href="<?php echo e(url('/'.$lang.'/home')); ?>" class="btn btn-default naviBtn" <?php if(strcmp($curpage,'home') == 0): ?> id="activeNav" <?php endif; ?>>HOME</a>
								<div class="btn-group">
									<button type="button" class="btn btn-default dropdown-toggle naviBtn" data-toggle="dropdown" <?php if(strcmp($curpage,'achievement') == 0 || strcmp($curpage,'people') == 0): ?> id="activeNav" <?php endif; ?>> ABOUT US <span class="caret"></span></button>
									<ul class="dropdown-menu navbar-dropdown" role="menu">
										<li class="navbar-dropdown"><a href="<?php echo e(url('/'.$lang.'/achievement')); ?>">ACHIEVEMENT</a></li>
										<li class="navbar-dropdown"><a href="<?php echo e(url('/'.$lang.'/people')); ?>">PEOPLE</a></li>
									</ul>
								</div>
								<div class="btn-group">
									<button class="btn btn-default dropdown-toggle naviBtn" data-toggle="dropdown" <?php if(strcmp($curpage,'news') == 0 || strcmp($curpage,'events') == 0): ?> id="activeNav" <?php endif; ?>> NEWS&EVENTS <span class="caret"></span></button>
									<ul class="dropdown-menu navbar-dropdown" role="menu">
										<li><a href="<?php echo e(url('/'.$lang.'/news')); ?>">NEWS</a></li>
										<li><a href="<?php echo e(url('/'.$lang.'/events')); ?>">EVENTS</a></li>
									</ul>
								</div>
								<a href="<?php echo e(url('/'.$lang.'/gallery')); ?>" class="btn btn-default naviBtn" <?php if(strcmp($curpage,'gallery') == 0): ?> id="activeNav" <?php endif; ?>>GALLERY</a>
								<a href="<?php echo e(url('/'.$lang.'/comments')); ?>" class="btn btn-default naviBtn" <?php if(strcmp($curpage,'comments') == 0): ?> id="activeNav" <?php endif; ?>>COMMENTS</a>
  							</div>
  						</td>
  					</tr>
  				</table>
  			</div>
  		</div>
  	</header>
      <?php echo $__env->yieldContent('content'); ?>
    <footer>
  		<div id="footerTop" class="container-fluid">
  			<button class="footerBtn" onclick="location.href='https://twitter.com/kridabudaya'"> <img src="<?php echo e(url('images/twitter.png')); ?>"> </button>
  			<button class="footerBtn" onclick="location.href='https://facebook.com/ligatarikridabudaya'"> <img src="<?php echo e(url('images/fb.png')); ?>"> </button>
  			<button class="footerBtn" onclick="location.href='https://www.instagram.com/kridabudaya/'"> <img src="<?php echo e(url('images/ig.png')); ?>"> </button>
  			<button class="footerBtn" onclick="location.href='https://www.youtube.com/channel/UCgJzdrK4a9kosMM4T9MMEjA'"> <img src="<?php echo e(url('images/yt.png')); ?>"> </button>
  		</div>
  		<div id="footerBtm" class="container-fluid">
  			&copy; 2016
  			ALL RIGHTS RESERVED.
  			POWERED BY <a href="https://laravel.com/">LARAVEL</a>.
  		</div>
  	</footer>
  </body>
</html>
