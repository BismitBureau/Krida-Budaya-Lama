<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="panel panel-default">
	 	<div class="panel-heading"> <h2> <?php echo e($message['name']); ?>  (<?php echo e($message['email']); ?>) | <?php echo e($message['date']); ?> </h2> </div>
	  	<div class="panel-body">
	  		<p> <?php echo preg_replace("/\n/", "<br />", $message['content']); ?> </p>
	  		<hr>
	  		<p> <?php echo e($message['website']); ?> </p>
	  	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>