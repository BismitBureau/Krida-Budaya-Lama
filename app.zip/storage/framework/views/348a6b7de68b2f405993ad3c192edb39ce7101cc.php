<?php $__env->startSection('styling'); ?>
  <script src="<?php echo e(url('javascript/people.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('style/mindex.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('style/mpeople.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="topBorder"></div>

<div id="peopleWrapper">
	<?php foreach($data["people"] as $people): ?>
	  <div class="peopleBox">
		<div class="flip-container" ontouchstart="this.classList.toggle('hover');">
		  <div class="flipper">
			<div class="front">
			  <img src="<?php echo e(url($people['photoURL'])); ?>" class="img-circle peoplePhoto" width="420px" height="420px">
			</div>
			<div class="back img-circle">
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["twitterURL"] ?>'"> <img src="<?php echo e(url('images/twitter.png')); ?>" width="52px"> </button>
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["facebookURL"] ?>'"> <img src="<?php echo e(url('images/fb.png')); ?>" width="54px"> </button>
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["instagramURL"] ?>'"> <img src="<?php echo e(url('images/ig.png')); ?>" width="54px"> </button>
			</div>
		  </div>
		</div>
		<div class="peopleName">
		  <p><?php echo e($people['name']); ?></p>
		</div>
		<div class="peoplePosition">
		  <p><?php echo e($people['subname']); ?></p>
		</div>
		<div class="peopleDesc">

		  <p> <?php if(strcmp($lang,'en')==0): ?> <?php echo preg_replace("/\n/", "<br />", $people['contenten']); ?> <?php else: ?> <?php echo preg_replace("/\n/", "<br />", $people['contentid']); ?> <?php endif; ?>  </p>
		</div>
	  </div>
	  
	  <div class="peopleSpace"></div>
	<?php endforeach; ?>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>