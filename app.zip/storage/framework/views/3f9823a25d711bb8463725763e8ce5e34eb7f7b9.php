<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        People
        <small>Edit</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/')); ?>"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li><a href="<?php echo e(url('admin/peoples')); ?>"> People</a></li>
        <li class="active"><a href="#">Edit</a></li>
    </ol>
</section>
<section class="content">
	<div class="box box-warning">
		<form role="form" method="post" action="<?php echo e(url('admin/update_people/'.$people['id'])); ?>" >
        <div class="box-body">
				<img src="<?php echo e(url($people['photoURL'])); ?>" width="25%">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter ..." value="<?php echo e($people['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Subname</label>
                    <input type="text" name="subname" class="form-control" placeholder="Enter ..." value="<?php echo e($people['subname']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Description (Indonesia)</label>
                    <textarea class="form-control" name="contentid" rows="5" placeholder="Enter ..."><?php echo e($people['contentid']); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Description (English)</label>
                    <textarea class="form-control" name="contenten" rows="5" placeholder="Enter ..."><?php echo e($people['contenten']); ?></textarea>
                </div>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-twitter-square"></i></span>
                    <input type="text" name="twitterURL" class="form-control" placeholder="Twitter" value="<?php echo e($people['twitterURL']); ?>">
                </div>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-facebook-square"></i></span>
                    <input type="text" name="facebookURL" class="form-control" placeholder="Facebook" value="<?php echo e($people['facebookURL']); ?>">
                </div>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-instagram"></i></span>
                    <input type="text" name="instagramURL" class="form-control" placeholder="Instagram" value="<?php echo e($people['instagramURL']); ?>">
                </div>
        </div>
        <div class="box-footer">
        	<button type="submit" class="btn btn-primary">Save</button>
        </div>
        </form>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>