<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="panel panel-default">
	 	<div class="panel-heading">Comments</div>
	  	<div class="panel-body">
	  			<form method="post" action="<?php echo e(url('admin/delete_comment')); ?>">
				  <table class="table table-hover">
				    <thead>
				      <tr>
				        <th>Name</th>
				        <th>Email</th>
				        <th>Website</th>
				        <th>Date </th>
				        <th> </th>
				        <th>Delete</th>
				      </tr>
				    </thead>
				    <tbody>
				      <?php foreach($data['comments'] as $comment): ?>
				     	 <tr <?php if($comment['read'] == false): ?> class="info" <?php endif; ?>>
				        	<td> <?php echo e($comment['name']); ?> </td>
				        	<td> <?php echo e($comment['email']); ?> </td>
				        	<td> <?php echo e($comment['website']); ?> </td>
				        	<td> <?php echo e($comment['date']); ?> </td>
				        	<td> <a href="<?php echo e(url('/admin/read/'.$comment['id'])); ?>"> read </a> <?php if(!$comment['read']): ?> <span class="label label-warning"> new/unread </span> <?php endif; ?> </td>
				       		<td> <input type="checkbox" name="delete_list[]" value="<?php echo e($comment['id']); ?>"> <label> delete </label> <br/> </td>
				      	 </tr>
				      <?php endforeach; ?>
				    </tbody>
				  </table>
			
				<input type="submit" name="delete slide(s)" value="delete comment(s)"/>
			</form>
	  	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>