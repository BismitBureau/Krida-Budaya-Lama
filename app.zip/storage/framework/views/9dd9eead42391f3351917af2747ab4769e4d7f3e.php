<?php $__env->startSection('content'); ?>
	<section class="content-header">
        <h1>
            Dashboard
            <small> Recruitment </small>
        </h1>
        <ol class="breadcrumb">
            <li class="active"><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        </ol>
    </section>
    <section class="content invoice">   
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    Formulir Pendaftaran Liga Tari UI Krida Budaya
                    <small class="pull-right">Date: <?php echo e($recruitment->date); ?></small>
                </h2>                            
            </div>
        </div>
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                <img src="<?php echo e(url($recruitment->imageURL)); ?>" class="img img-responsive" style="width:150px; height:225px">
            </div>
            <div class="col-sm-4 invoice-col">
                <b>NPM <?php echo e($recruitment->npm); ?></b><br>
                <b>Nama Lengkap:</b><br> <?php echo e($recruitment->name); ?><br>
                <b>Nama Orang Tua:</b><br> <?php echo e($recruitment->orangtua); ?><br>
                <b>Tempat & Tanggal Lahir:</b><br> <?php echo e($recruitment->ttl); ?><br>
                <b>Fakultas & Jurusan:</b><br> <?php echo e($recruitment->fj); ?><br>
                <b>Angkatan:</b><br> <?php echo e($recruitment->angkatan); ?> <br>
                <b>Nomor Telepon: </b><br> <?php echo e($recruitment->nomor); ?>


            </div>
            <div class="col-sm-4 invoice-col">
                <b>Alamat:</b>
                <address>
                    <?php echo e($recruitment->alamat); ?>

                </address>
                <b> Email: </b><br> <?php echo e($recruitment->email); ?> <br>
                <b> Twitter: </b><br> <?php echo e($recruitment->Twitter); ?> <br>
                <b> Instagram: </b><br> <?php echo e($recruitment->Instagram); ?> <br>
                <b> Facebook: </b><br> <?php echo e($recruitment->Facebook); ?> <br>
                <b> Line: </b><br> <?php echo e($recruitment->Line); ?>

            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Pengalaman/Prestasi</h3>
                    </div>
                    <div class="box-body">
                        <ul>
                        <?php foreach(preg_split("/\\r\\n|\\r|\\n/", $recruitment->prestasi) as $line): ?>
                            <li>
                                <?php echo e($line); ?>

                            </li>
                        <?php endforeach; ?>
                        <ul>
                    </div>
                </div>                         
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Seni</h3>
                    </div>
                    <div class="box-body">
                        <ul>
                        <?php foreach(preg_split("/\\r\\n|\\r|\\n/", $recruitment->seni) as $line): ?>
                            <li>
                                <?php echo e($line); ?>

                            </li>
                        <?php endforeach; ?>
                        <ul>
                    </div>
                </div>                         
            </div>           
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Alasan</h3>
                    </div>
                    <div class="box-body">
                        <p>
                            <?php echo nl2br($recruitment->alasan); ?>

                        </p>
                    </div>
                </div>                         
            </div>           
        </div>


        <div class="row no-print">
            <div class="col-xs-12">
                <b>Status Pendaftaran:</b> 
                <?php if($recruitment->status == 0): ?>
                    <span class="label label-warning">Pending</span>
                <?php elseif($recruitment->status == 1): ?>
                    <span class="label label-success">Approved</span>
                <?php else: ?>
                    <span class="label label-danger">Denied</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="row no-print">
            <div class="col-xs-12">
                <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button> 
                <a href="<?php echo e(url('admin/dashboard/form/0/'.$recruitment->id)); ?>" class="btn btn-solid pull-right" style="margin-right: 5px;"> Hilangkan tanda </a>
                <a href="<?php echo e(url('admin/dashboard/form/1/'.$recruitment->id)); ?>" class="btn btn-primary pull-right" style="margin-right: 5px;"> Tandai sebagai diterima </a>
                <a href="<?php echo e(url('admin/dashboard/form/2/'.$recruitment->id)); ?>" class="btn btn-danger pull-right" style="margin-right: 5px;"> Tandai sebagai ditolak </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>