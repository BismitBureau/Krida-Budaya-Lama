<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Gallery
        <small>Manager</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Admin </a></li>
        <li class="active"><a href="#">Gallery</a></li>
    </ol>
</section>
<section class="content">
	<div class="box box-warning">
	    <div class="box-header">
	        <h3 class="box-title">Add new album</h3>
	    </div>
	    <form role="form" action="upload_gallery" method="post">
	    <div class="box-body">
	            <div class="form-group">
	                <label>Title Indonesia</label>
	                <input type="text" name="titleid[]" class="form-control" placeholder="Enter ...">
	            </div>  
	            <div class="form-group">
	                <label>Title English</label>
	                <input type="text" name="titleen[]" class="form-control" placeholder="Enter ...">
	            </div>
	    </div>
	    <div class="box-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>                      
	    </form>
	</div>
	<div class="box box-danger">
		<div class="box-header">
			<h3 class="box-title">Delete/edit album</h3>
		</div>
		<form action="delete_gallery" method="post">
		<div class="box-body">
			<?php foreach($data["gallery"] as $album): ?>
			<div class="box box-solid">
				<div class="box-header">
					<h4 class="box-title"> <i class="fa fa-picture-o"></i> <?php echo e($album['titleid']); ?> | <?php echo e($album['titleen']); ?></h4>
				</div>
				<div class="box-body">
					<label> content (English) </label>
					<p> <?php echo e(strip_tags($album['descriptionen'])); ?>... </p>
					<label> content (Indonesia) </label>
					<p> <?php echo e(strip_tags($album['descriptionid'])); ?>... </p>
				</div>
				<div class="box-footer">
                	<div class="row">
                		<div class="col-md-12">
		                	<div class="pull-left">
				        		<input type="checkbox" name="delete_list[]" value="<?php echo e($album['id']); ?>"> <label> tandai untuk delete album </label> <br/>
		                	</div>
		                	<div class="pull-right">
		                		<a class="btn btn-primary btn-sm" href="<?php echo e(url('admin/galleries/edit/'.$album['id'])); ?>"> edit </a>
		                	</div>
	                	</div>
               	 	</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	    <div class="box-footer">
				<input type="submit" class="btn btn-danger btn-lg" name="delete event(s)" value="Click here to delete selected post(s)" style="width: 100%;"/>
        </div>       
    	</form>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>