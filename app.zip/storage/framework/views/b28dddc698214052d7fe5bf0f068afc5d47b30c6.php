<link rel="stylesheet" href="<?php echo e(url('style/basic.css')); ?>">
<script src="<?php echo e(url('javascript/dropzone.js')); ?>"></script>
<script src="http://code.jquery.com/jquery-2.2.1.min.js"></script>
<script src="<?php echo e(url('javascript/plugins/ckeditor/ckeditor.js')); ?>" type="text/javascript"></script>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        News
        <small>Edit</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin')); ?>"><i class="fa fa-dashboard"></i> Admin </a></li>
        <li><a href="<?php echo e(url('admin/newsmanager')); ?> ">News</a></li>
        <li class="active">Edit</li>
    </ol>
</section>
<section class="content">

	<div class="box box-solid">
		<div class="box-header">
			<h4 class="box-title"> Upload image(s) </h4>
		</div>
		<div class="box-body">
			<form action="<?php echo e(url('admin/upload_image/news/'.$news['id'])); ?>" class="dropzone" id="my-awesome-dropzone">
			</form>
		</div>
		<div class="box-footer">
			<label> dimohon melakukan refresh setiap kali selesai meng-upload image </label><br>
			<a href="<?php echo e(url('admin/newsmanager/edit/'.$news['id'])); ?>"class="btn btn-primary"> Refresh </a>
		</div>
	</div>
	<script type="text/javascript">
		function copyLink(imageurl) {
			alert(imageurl);
			var dummy = document.createElement('input');
			document.body.appendChild(dummy);
			dummy.setAttribute('id', 'dummy_id');
			document.getElementById('dummy_id').value = imageurl;
			dummy.select();
			document.execCommand('copy');
			document.body.removeChild(dummy);
		}
		$(function() {
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace('contentid');
                CKEDITOR.replace('contenten');
        });
	</script>
	<div class="box box-solid">
		<div class="box-header">
			<h3 class="box-title"> Images </h3>
		</div>
		<form action="<?php echo e(url('admin/newsmanager/delete_image/'.$news['id'])); ?>" method="post">
		<div class="box-body">

			<?php for($i = 0; $i < count($images);): ?>
			<div class="row">
				<?php for($cnt = 0; $cnt < 3 && $i < count($images); $cnt++, $i++): ?>
				<?php $url = url('admin/setprimaryimage/news/'.$news['id'].'/'.$images[$i]['id']); ?>
				<div class="col-md-4">
					<div class="box box-<?php echo e(strcmp($news['imageURL'],$images[$i]['imageURL']) == 0 ? 'success' : 'primary'); ?>">
						<div class="box-header">
							<h4 class="box-title"> <i class="fa fa-picture-o" aria-hidden="true"></i> <?php echo e($i+1); ?> <?php echo e(strcmp($news['imageURL'],$images[$i]['imageURL']) == 0 ? '(Primary Image)' : ''); ?> </h4>
						</div>
						<div class="box-body">
							<img src="<?php echo e(url($images[$i]['imageURL'])); ?>" class="img-responsive" style="height:300px;">
						</div>
						<div class="box-footer">
							<div class="row">
				        		<div class="col-md-4">
					        		<input type="checkbox" name="delete_list[]" value="<?php echo e($images[$i]['id']); ?>"> <label> delete? </label> <br/>
						        </div>
						        <div class="col-md-4">
				                	<a class="btn btn-primary btn-sm" href="<?php echo e($url); ?>"> set as primary </a>
				            	</div>
				            	<div class="col-md-4">
				            		<?php $hehe = url($images[$i]['imageURL']); ?>
				            		<a class="btn btn-success btn-sm" onclick="copyLink('<?php echo e($hehe); ?>')"> copy link </a>
				            	</div>
				       	 	</div>
						</div>
					</div>
				</div>
				<?php endfor; ?>
			</div>
			<?php endfor; ?>
		</div>	    
		<div class="box-footer">
			<input type="submit" class="btn btn-danger btn-lg" name="delete image(s)" value="Click here to delete selected image(s)" style="width: 100%;"/>
        </div>  
		</form>
	</div>
	<div class="box box-solid">
		<div class="box-header">
			<h3 class="box-title"> Text editor </h3>
		</div>
		<form method="post" action="<?php echo e(url('admin/update_news/'.$news['id'])); ?>">
			<div class="box-body">
				<div class="form-group">
	                <label>Title (Indonesia)</label>
	                <input type="text" name="titleid" class="form-control" placeholder="Enter ..." value="<?php echo e($news['titleid']); ?>" required>
	            </div>
				<div class="form-group">
	                <label>Title (English)</label>
	                <input type="text" name="titleen" class="form-control" placeholder="Enter ..." value="<?php echo e($news['titleen']); ?>" required>
	            </div>

	            <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <input type="date" name="date" class="form-control" value="<?php echo e($news['date']); ?>" required>
                </div>

	            <div class="form-group">
	            	<label> Editor (Indonesia) </label>
	            	<textarea id="contentid" name="contentid" rows="10" cols="80">
	                    <?php echo $news['contentid']; ?>

	                </textarea> 
	            </div>

	            <div class="form-group">
	            	<label> Editor (English) </label>
	            	<textarea id="contenten" name="contenten" rows="10" cols="80">
	                    <?php echo preg_replace("/\n/", "<br />", $news['contenten']); ?>

	                </textarea> 
	            </div>
			</div>
			<div class="box-footer">
				<input type="submit" class="btn btn-info" value="save">
			</div>
		</form>
	</div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>