<?php $__env->startSection('styling'); ?>
  <script src="<?php echo e(url('javascript/people.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('style/index.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('style/people.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="topBorder"></div>

<div id="peopleWrapper">
	<?php foreach($data["people"] as $people): ?>
	  <div class="peopleBox">
		<div class="flip-container" ontouchstart="this.classList.toggle('hover');">
		  <div class="flipper">
			<div class="front">
			  <img src="<?php echo e(url($people['photoURL'])); ?>" class="img-circle peoplePhoto" width="225px" height="225px">
			</div>
			<div class="back img-circle">
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["twitterURL"] ?>'"> <img src="<?php echo e(url('images/twitter.png')); ?>" width="20px"> </button>
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["facebookURL"] ?>'"> <img src="<?php echo e(url('images/fb.png')); ?>" width="22px"> </button>
			  <button class="peopleBtn" onclick="location.href='<?php echo $people["instagramURL"] ?>'"> <img src="<?php echo e(url('images/ig.png')); ?>" width="22px"> </button>
			</div>
		  </div>
		</div>
		<div class="peopleName">
		  <?php echo e($people['name']); ?>

		</div>
		<div class="peoplePosition">
		  <?php echo e($people['subname']); ?>

		</div>
		<div class="peopleDesc">
		  <?php if(strcmp($lang,'en')==0): ?> <?php echo preg_replace("/\n/", "<br />", $people['contenten']); ?> <?php else: ?> <?php echo preg_replace("/\n/", "<br />", $people['contentid']); ?> <?php endif; ?>
		</div>
	  </div>
	  
	  <div class="peopleSpace"></div>
	<?php endforeach; ?>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>