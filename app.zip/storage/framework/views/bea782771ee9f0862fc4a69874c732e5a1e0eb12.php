<?php $__env->startSection('styling'); ?>
  <script src="<?php echo e(url('javascript/gallery.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('style/index.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('style/gallery.css')); ?>">
  <script>
      function ons(obj){
          console.log(obj.value);
      }
  </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php
	$count = 0;
?>
<div class="topBorder"></div>

<div id="galleryContent">
    <div class="form-group">
        <label for="origin">Asal</label>
        <select class="form-control" id="origin" onchange="window.location.href = '<?php echo e(url($lang . '/gallery')); ?>/' + this.value">
            <?php foreach($data["lsorigin"] as $lsorigins): ?>
            <?php
                $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '_', $lsorigins['origin']));
                $selected = strcmp($slug, $data['orig']) == 0 ? 'selected' : ''
            ?>
            <option value="<?php echo e($slug); ?>" <?php echo e($selected); ?>><?php echo e($lsorigins["origin"]); ?></option>
            <?php endforeach; ?>
        </select>
    </div>

  <?php foreach($data["gallery"] as $gallery): ?>
  <?php if($data['orig'] == 'all' || $data['orig'] == strtolower(preg_replace('/[^a-z0-9]+/i', '_', $gallery['origin']))): ?>
	<!-- tari 1 -->
  <div class="container-fluid galleryPost">
    <div class="row">
      <a class="<?php echo e('galleryModalLink'.(++$count)); ?> ">
        <img src="<?php echo e(url($gallery['imageURL'])); ?>" class="img-responsive">
        <div class="galleryInfo">
          <h1><?php echo e(strcmp($lang,'en')==0 ? $gallery['titleen'] : $gallery['titleid']); ?></h1>
		  <p>
			<?php echo e(strcmp($lang,'en')==0 ? $gallery['descriptionen'] : $gallery['descriptionid']); ?>         
		  </p>
        </div>
      </a>
    </div>
  </div>

	<!-- isi foto tari 1-->
  <div id="<?php echo e('galleryModal'.$count); ?>" class="modal">
	<div class="galleryModal-content">
      
	  <div class="galleryModal-header">
		<span class="close glyphicon glyphicon-remove tolkon<?php echo e($count); ?>"></span>
        <div class="galleryModalTitle">
          <?php echo e(strcmp($lang,'en')==0 ? $gallery['titleen'] : $gallery['titleid']); ?>

        </div>
      </div>

      <div class="galleryModal-body">
        <?php foreach($data['images'] as $image): ?>
        <?php if($image['gallery_id'] == $gallery['id'] && strcmp($image['imageURL'],$gallery['imageURL'])!=0): ?>
        <div class="responsive">
          <div class="imgPost">
            <img class="thisImg" src="<?php echo e(url($image['imageURL'])); ?>">
            <div class="imgDesc">
				<?php echo e(strcmp($lang,'en')==0 ? $image['descriptionen'] : $image['descriptionid']); ?>

            </div>
			<!--
            <div class="imgTitle">
              <?php echo e(strcmp($lang,'en')==0 ? $image['titleen'] : $image['titleid']); ?>

            </div>
			-->
          </div>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>

        <div class="clearfix"></div>
      </div>

      <div class="galleryModal-footer">
      </div>
	  
    </div>
  </div>

  <div class="gallerySpace"></div>
  <?php endif; ?>
  <?php endforeach; ?>

  
  <!-- zoom tiap foto tari -->
  <div id="imgModal" class="modal">
	<span class="closeImg glyphicon glyphicon-remove"></span>
	  <img class="imgModal-content" id="img01">
	  <div id="title">DESCRIPTION</div>
	  <div id="caption"></div>
  </div>
  
</div>

<?php
	$count = 0;
?>
<script type="text/javascript">
	$(document).ready(function() {
		
		<?php foreach($data["gallery"] as $gallery): ?>
		var <?php echo e('modal'.(++$count)); ?> = document.getElementById('<?php echo e("galleryModal".$count); ?>');
		var <?php echo e('span'.$count); ?> = document.getElementsByClassName("close glyphicon glyphicon-remove tolkon<?php echo e($count); ?>")[0];
	
		$("a.<?php echo e('galleryModalLink'.$count); ?>").click(function(){
		   <?php echo e('modal'.$count); ?>.style.display = "block";
		 });
		 
		<?php echo e('span'.$count); ?>.onclick = function() {
		    <?php echo e('modal'.$count); ?>.style.display = "none";
		}
		
		window.onclick = function(event) {
			if (event.target == <?php echo e('modal'.$count); ?>) {
				<?php echo e('modal'.$count); ?>.style.display = "none";
			}
		}
		<?php endforeach; ?>
		
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>