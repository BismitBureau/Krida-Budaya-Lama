<?php $__env->startSection('styling'); ?>
  <script src="<?php echo e(url('javascript/myScript.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('style/index.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('style/search.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="topBorder"></div>	
	
	<div id="content">
		<div class="container-fluid">
			<div class="row">
				<div class="wrapper">
					<div class="searchTitlePage">
						search result for: <?php echo e($text); ?>

					</div>

					<?php if(count($event) == 0 && count($news) == 0): ?>
						not found
					<?php endif; ?>

					
					<?php foreach($event as $tot): ?>
					<div class="searchPost">
						<table>
							<tr>
								<div class="searchTitle">
									<?php echo e(strcmp($lang,'en') == 0 ? $tot->titleen : $tot->titleid); ?>

								</div>
							</tr>
							<tr>
								<div class="searchInfo">
									<?php echo e($tot->date); ?>

								</div>
							</tr>
							<tr>
								<div class="searchSnippet">
									<?php echo e(strcmp($lang,'en')==0 ? $tot->snippeten : $tot->snippetid); ?>

								</div>
							</tr>
							<tr>
								<div class="readMoreSearch">
									<?php $tmplink = url('/'.$lang.'/events/'.$tot->id) ?>
									<button onclick="location.href='<?php echo e($tmplink); ?>'"><span>read more</span></button>
								</div>
							</tr>
							<tr>
								<div class="searchInfo2">
									Posted in Events
								</div>
							</tr>
						</table>
					</div>
					
					<div class="searchSpace"></div>

					<?php endforeach; ?>
					
					<?php foreach($news as $tot): ?>
					<div class="searchPost">
						<table>
							<tr>
								<div class="searchTitle">
									<?php echo e(strcmp($lang,'en') == 0 ? $tot->titleen : $tot->titleid); ?>

								</div>
							</tr>
							<tr>
								<div class="searchInfo">
									<?php echo e($tot->date); ?>

								</div>
							</tr>
							<tr>
								<div class="searchSnippet">
									<?php echo e(strcmp($lang,'en')==0 ? $tot->snippeten : $tot->snippetid); ?>

								</div>
							</tr>
							<tr>
								<div class="readMoreSearch">
									<?php $tmplink = url('/'.$lang.'/news/'.$tot->id) ?>
									<button onclick="location.href='<?php echo e($tmplink); ?>'"><span>read more</span></button>
								</div>
							</tr>
							<tr>
								<div class="searchInfo2">
									Posted in News
								</div>
							</tr>
						</table>
					</div>
					
					<div class="searchSpace"></div>

					<?php endforeach; ?>
					
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>