<?php $__env->startSection('content'); ?>
	<?php if(isset($successMessage)): ?>
		<div class="alert alert-success">
		  <strong>Request Success!</strong> Password changed!
		</div>
	<?php endif; ?>
	<?php if(isset($failMessage)): ?>
		<div class="alert alert-danger">
		  <strong>Request Failed!</strong> <?php echo e($failMessage); ?>

		</div>
	<?php endif; ?>
	<form method="post" action="update_password">
		Current Password : 
		<input type="password" name="curpass">
		New Password :
		<input type="password" name="newpass">
		Confirm New Password :
		<input type="password" name="confirmpass">
		<input type="submit" value="Save Password"> </input>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>