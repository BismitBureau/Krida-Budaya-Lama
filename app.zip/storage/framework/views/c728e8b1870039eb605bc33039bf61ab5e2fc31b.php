<?php $__env->startSection('styling'); ?>
  <link rel="stylesheet" href="<?php echo e(url('style/marticle.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('style/index.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		<div class="topBorder"></div>
		
		<div class="container-fluid">
			<div class="row">
				<div class="wrapper">
					<table>
						<tr>
							<div class="articleTitle">
								DIRGAHAYU 32 TAHUN LTMUIKB
							</div>
						</tr>
						<tr>
							<div class="articleInfo">
								Posted on March 18, 2015 by admin
							</div>
						</tr>
						<tr>
							<div class="articleImage">
								<div id="postSlider" class="carousel slide carousel-fade" data-ride="carousel">
									<!-- Indicators -->
									<ol class="carousel-indicators">
										<li data-target="#postSlider" data-slide-to="0" class="active"></li>
										<li data-target="#postSlider" data-slide-to="1"></li>
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner" role="listbox">
										<div class="item active">
											<img src="<?php echo e(url('images/contoh.jpg')); ?>" class="img-responsive">
										</div>

										<div class="item">
											<img src="<?php echo e(url('images/saman.jpg')); ?>" class="img-responsive">
										</div>
									</div>

									<!-- Left and right controls -->
									<a class="left carousel-control" href="#postSlider" role="button" data-slide="prev">
										<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
										<span class="sr-only">Prev</span>
									</a>
									<a class="right carousel-control" href="#postSlider" role="button" data-slide="next">
										<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
										<span class="sr-only">Next</span>
									</a>
								</div>
							</div>
						</tr>
						<tr>
							<div class="articleContent">
								Hari ketika Liga Tari Mahasiswa Universitas Indonesia Krida Budaya terlahir. 
								Hari dimana Mahasiswa/i bisa mengapresiasikan diri nya dalam bidang Tari dan Musik Tradisional. 
								Hari dimana Budaya Indonesia masih dapat di lestarikan oleh para generasi-generasi muda penerus bangsa.
								Kini Liga Tari Mahasiwa UI Krida Budaya sudah genap berusia 32 tahun. 
								Meskipun tidak secara besar-besaran, kami tetap merayakan hari kelahiran LTMUIKB sebagai wujud rasa syukur kami.
								Di usia yg ke-32 ini kami tetap terus ikut berkontribusi dalam pelestarian budaya Indonesia. 
								Peran rekan-rekan dan kerabat keluarga Liga Tari Mahasiswa UI Krida Budaya menjadi semacam penyemangat 
								dan pendukung yang luar biasa bagi kami. Sejarah terbentuknya LTMUIKB hingga kini terus menjadi
								cerita turun temurun dalam keluarga kami. Terima kasih telah membangun kami, menemani kami, membimbing kami,
								belajar bersama kami, dan tumbuh bersama kami. Di 32 tahun ini, semoga semua ilmu dapat terus membawa 
								kami maju kejenjang yang lebih baik.Semoga semua kesan dan kenangan yang tercipta dapat terus mengikat kita 
								dalam satu keluarga.
							</div>
						</tr>
						<tr>
							<div class="articleButton">
								<button type="button" class="btn btn-default calendarBtn" id="prev"><span class="glyphicon glyphicon-chevron-left"></span>prev post</button>						
								<button type="button" class="btn btn-default calendarBtn" id="next">next post<span class="glyphicon glyphicon-chevron-right"></span></button>
							</div>
						</tr>
					</table>
				</div>
			</div>
			
			<div class="row">
				<div class="wrapper2">
					<table>
						<tr>
							<div class="topicBoxTitle">
								RELATED TOPICS
							</div>
						</tr>
						
						<tr>
							<a href="#">
								<div class="topicPost">
									<div class="topicTitle">
										DIRGAHAYU 32 TAHUN LTMUIKB
									</div>
								</div>
							</a>
						</tr>
						<tr>
							<a href="#">
								<div class="topicPost">
									<div class="topicTitle">
										DIRGAHAYU 32 TAHUN LTMUIKB
									</div>
								</div>
							</a>
						</tr>
						<tr>
							<a href="#">
								<div class="topicPost">
									<div class="topicTitle">
										DIRGAHAYU 32 TAHUN LTMUIKB
									</div>
								</div>
							</a>
						</tr>
					</table>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>