<?php $__env->startSection('styling'); ?>
  <link rel="stylesheet" href="<?php echo e(url('style/mindex.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="topBorder"></div>

<div class="container-fluid home">
  <div class="row">
    <div id="homeSlider" class="carousel slide carousel-fade" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <?php for($i = 0; $i < count($data['slides']); $i++): ?>
          <li data-target="#homeSlider" data-slide-to="<?php echo e($i); ?>" <?php if($i == 0): ?> class="active" <?php endif; ?>></li>
        <?php endfor; ?>
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner" role="listbox">
        <?php for($i = 0; $i < count($data['slides']); $i++): ?>
          <div class="item <?php if($i == 0): ?> active <?php endif; ?>">
            <img src="<?php echo e(url($data['slides'][$i]['imageURL'])); ?>" class="img-responsive">
          </div>
        <?php endfor; ?>
      </div>

      <!-- Left and right controls -->
      <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Prev</span>
      </a>
      <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>

	<div id="wrapperHome">
	
		<div class="row">
			<div id="about">
				<table>
					<tr>
						<div class="aboutTitle">
							ABOUT KRIDA BUDAYA
						</div>
					</tr>
					<tr>
						<div id="aboutContent">
							<?php if(strcmp($lang,"en")==0): ?>
								<!-- english -->
								<?php echo e($data['about']['abouten']); ?>

							<?php else: ?>
								<!-- indonesia -->
								<?php echo e($data['about']['aboutid']); ?>

							<?php endif; ?>
						</div>
					</tr>
				</table>
			</div>
		</div>
		
		<div class="spaceHome"></div>
		
		<div class="row">
			<div id="cp">
				<table>
					<tr>
						<div class="cpTitle">
							LIGA TARI FOR HIRE
						</div>
					</tr>
					<tr>
						<div class="cpTitle2">
							MARKETING
						</div>
					</tr>
				</table>
				
				<table>
					<tr>
						<td>
							<div class="teleponCp">
								+62 877 93462282
							</div>
						</td>
						<td>
							<div class="namaCp">
								Via
							</div>
						</td>
					</tr>
					<tr>
						<td>
							<div class="teleponCp">
								+62 812 10246100
							</div>
						</td>
						<td>
							<div class="namaCp">
								Sheli
							</div>
						</td>
					</tr>
				</table>
				
				<table>
					<tr>
						<td>
							<div class="logoEmailCp">
								<img src="<?php echo e(url('images/gmail-logo.ico')); ?>" alt="gmail-logo">
							</div>
						</td>
						<td>
							<div class="alamatEmailCp">
								indonesia.kridabudaya
								@gmail.com
							</div>
						</td>
					</tr>
				</table>
			</div>
		</div>
		
		<div class="spaceHome"></div>
		
		<div class="row">
			<div id="testimonialBox" class="carousel slide carousel-fade" data-ride="carousel">
			  <!-- Indicators -->
			  <ol class="carousel-indicators">
				<?php for( $i = 0; $i < count($data['testimonis']); $i++): ?>
				  <li data-target="#testimonialBox" data-slide-to="<?php echo e($i); ?>" <?php if($i==0): ?> class="active" <?php endif; ?>></li>
				<?php endfor; ?>
			  </ol>

			  <!-- Wrapper for slides -->
			  <div class="carousel-inner" role="listbox">
				<?php for( $i = 0; $i < count($data['testimonis']); $i++): ?>
				  <div class="item <?php if($i==0): ?> active <?php endif; ?>">
					<div class="testiName"><?php echo e($data['testimonis'][$i]['name']); ?></div>
					<div class="testiContent">
					  <?php echo e(strcmp($lang,"en") == 0 ? $data['testimonis'][$i]['contenten'] : $data['testimonis'][$i]['contentid']); ?>

					</div>
				  </div>
				<?php endfor; ?>
			  </div>

			  <!-- Left and right controls -->
			  <a class="left carousel-control" href="#testimonialBox" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				<span class="sr-only">Prev</span>
			  </a>
			  <a class="right carousel-control" href="#testimonialBox" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			  </a>
			</div>
		</div>
		
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>