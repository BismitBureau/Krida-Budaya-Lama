<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Testimonial Box
        <small>Edit</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('admin/')); ?>"><i class="fa fa-dashboard"></i> Admin</a></li>
        <li><a href="<?php echo e(url('admin/testimonial')); ?>"> Testimonial Box</a></li>
        <li class="active"><a href="#">Edit</a></li>
    </ol>
</section>
<section class="content">
	<div class="box box-warning">
		<form role="form" method="post" action="<?php echo e(url('admin/update_testimoni/'.$testimoni['id'])); ?>">
        <div class="box-body">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter ..." value="<?php echo e($testimoni['name']); ?>">
                </div>
                <div class="form-group">
                    <label>Content English</label>
                    <input type="text" name="contenten" class="form-control" placeholder="Enter ..." value="<?php echo e($testimoni['contenten']); ?>">
                </div>
                <div class="form-group">
                    <label>Content Indonesia</label>
                    <input type="text" name="contentid" class="form-control" placeholder="Enter ..." value="<?php echo e($testimoni['contentid']); ?>">
                </div>
        </div>
        <div class="box-footer">
        	<button type="submit" class="btn btn-primary">Save</button>
        </div>
        </form>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>